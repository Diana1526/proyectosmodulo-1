#variable de presio de los productos
saco_arroz1 = int(input("Ingrese el precio del saco de arroz: "))
cantidad_arroz1 = 1

pote_aceite2 = int(input("Ingrese el precio del pote de aceite: "))
cantidad_aceite2 = 1

dos_pollo3 = int(input("Ingrese el precio de dos pollos: "))
cantidad_pollo3 = 2

lata_salsa4 = int(input("Ingrese el precio de la lata de salsa: "))
cantidad_salsa4 = 2




#la variable de descuento
descuento=0.20

#la variable del impuesto
tasa_impuesto=0.18

#calcular_subtotal
subtotal=(saco_arroz1*cantidad_arroz1 +
          pote_aceite2*cantidad_aceite2 +
          dos_pollo3*cantidad_pollo3 +
          lata_salsa4*cantidad_salsa4)

#Aplicar descuento
subtotal_descuento=subtotal*descuento

#total despues del descuento
subtotaldescuento=subtotal-subtotal_descuento

#Calcular el impuesto 
impuesto=subtotaldescuento*tasa_impuesto

#calculo despues del impuesto total a pagar

subtotal_impuesto=impuesto + subtotaldescuento

print("subtotal",subtotal)
print("descuento",subtotal_descuento)
print("impuesto", impuesto)
print("total",subtotal_impuesto)
