#Recomendacion de vestimenta segun el cambio climatico

temperatura = 25

if temperatura >= 30:
    print("ropa ligera como camisetas y shorts.")
elif temperatura >= 20:
    print("El clima es cálido,una camiseta y jeans.")
elif temperatura >= 10:
    print("Hace un poco de frío,una chaqueta ligera.")
elif temperatura >= 0:
    print("Hace frío, es mejor usar un abrigo y ropa abrigada.")
else:
    print("Hace mucho frío, asegúrate de usar un abrigo muy grueso,y un gorro.")
