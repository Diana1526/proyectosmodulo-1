#sumar los numerosd del 1 al 10 uando un bucle

# Inicializar la variable que almacenará la suma
suma = 0

# Usar un bucle for para iterar del 1 al 10
for numero in range(1, 11):
    suma += numero  

# Imprimir el resultado
print("La suma de los números del 1 al 10 es:", suma)
