num1=20
num2=30
num3=40
num4=50
suma= num1 + num2
multiplicar= num3 * num4
print(" el valor de la suma es: ")
print(suma)
print("el valor de la multipilcacion es :")
print(multiplicar)
