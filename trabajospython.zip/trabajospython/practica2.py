num1=int(input("ingresa el primer valor:"))
num2=int(input("ingresa el segundo valor:"))
num3=int(input("ingresa el tercer valor:"))
num4=int(input("ingresa el cuarto valor:"))

suma=(num1 + num2 + num3 + num4)
promedio= suma / 4
print("la suma de los cuatros valores son:")
print(suma)
print("el valor del promedio es:")
print(promedio)
          
