#iterar sobre una cadena de caracteres usando un bucle .>


# Definir la cadena de caracteres
cadena = "python"

# Inicializar el índice
i = 0

# Usar un bucle while para iterar sobre cada carácter en la cadena
while i < len(cadena):
    print(cadena[i])
    i += 1
