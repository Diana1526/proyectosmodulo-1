# iterar sobre caracteres de una cadena

# La cadena a iterar
cadena = "python"

# Usar un bucle for para iterar sobre cada carácter en la cadena
for caracter in cadena:
    print(caracter)
