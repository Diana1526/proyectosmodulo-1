saldo = 1000.00
usuario = "Carlos Garcia"
numero_transaccion = 1

while True:
    print("\nMenu:")
    print("1. Consultar saldo.")
    print("2. Depositar dinero.")
    print("3. Transferir dinero.")
    print("4. Salir")

    seleccion = input("Seleccione una opción (1-4): ")

    if seleccion == "1":
        print(f"Hola {usuario}, su saldo actual es: ${saldo:.2f}")
    elif seleccion == "2":
        cantidad = float(input("Ingrese la cantidad a depositar: "))
        if cantidad > 0:
            saldo += cantidad
            print(f"Has depositado ${cantidad:.2f}. Su nuevo saldo es: ${saldo:.2f}")
            print(f"Número de transacción: {numero_transaccion}")
            numero_transaccion += 1
        else:
            print("La cantidad debe ser positiva.")
    elif seleccion == "3":
        cantidad = float(input("Ingrese la cantidad a transferir: "))
        if cantidad > 0:
            if cantidad <= saldo:
                saldo -= cantidad
                print(f"Has transferido ${cantidad:.2f}. Su nuevo saldo es: ${saldo:.2f}")
                print(f"Número de transacción: {numero_transaccion}")
                numero_transaccion += 1
            else:
                print("Fondos insuficientes para realizar la transferencia.")
        else:
            print("La cantidad debe ser positiva.")
    elif seleccion == "4":
        print("Saliendo del sistema...")
        break
    else:
        print("Opción no válida, por favor, seleccione una opción del 1 al 4")

print("Gracias por utilizar nuestro servicio.")
