temperatura = 25  

if temperatura >= 30:
    print("Hace mucho calor.")
elif temperatura >= 20:
    print("El clima es cálido.")
elif temperatura >= 10:
    print("El clima es fresco.")
elif temperatura >= 0:
    print("Hace frío.")
else:
    print("Hace mucho frío.")
