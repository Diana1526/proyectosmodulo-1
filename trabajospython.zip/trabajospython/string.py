mensaje = "Hola"
mensaje += " "
mensaje += "Michael"
print(mensaje)

print("concatanacion:")
mensaje = "Hola"
espacio = " "
nombre = "Michael"
print(mensaje + espacio + nombre)

numero_uno = 4
numero_dos =6
resultado = numero_uno + numero_dos
resultado = str(resultado)
print("el resultado de la suma es :" + resultado)

print("Busqueda:")

mensaje = "Hola Ernesto"
buscar_subcadena = mensaje.find("Ernesto")
print(buscar_subcadena)

print("extraer subcadena")

mensaje = ("Hola Ernesto")
extraer_subcadena = mensaje[1:8]
print(extraer_subcadena)

print("comparacion")

mensaje_uno = "hola"
mensaje_dos = "hola"
print(mensaje_uno == mensaje_dos)

