def dar_beso():
    # Paso 1: Asegurarse de que ambas personas quieran el beso
    consentimiento = input("Ambas personas quieren el beso: ")
    

    # Paso 2: Acercarse a la otra persona
    print("Acercándose a la otra persona...")

     # Paso 3: Establecer contacto visual con la persona
    print("Estableciendo contacto visual...")

    # Paso 4: Cerrar los ojos
    print("Cerrando los ojos...")

    # Paso 5: Dar el beso
    print("Dando el beso...")

    return "El beso se ha dado exitosamente."

# Ejecutar el algoritmo
resultado = dar_beso()
print(resultado)





