print("esto es una suma")
numero_uno = 2
numero_dos = 4
resultado = numero_uno + numero_dos
print(resultado)




