x=12
y=56
suma= x + y
print(suma)
      
