# PIN correcto almacenado en el sistema
PIN_correcto = "1234"  # El PIN correcto se almacena como una cadena

# Número máximo de intentos
max_intentos = 3

# Inicializar el contador de intentos
intentos = 0

# Variable para almacenar el PIN ingresado por el usuario
PIN_ingresado = ""

while intentos < max_intentos:
    # Pedir al usuario que ingrese su PIN
    PIN_ingresado = input("Por favor ingrese su PIN: ")

    # Verificar si el PIN ingresado es correcto
    if PIN_ingresado == PIN_correcto:
        print("PIN correcto. Bienvenido a su cuenta popular, Carlos Garcia....")
        break
    else:
        intentos += 1
        print(f"PIN incorrecto. Le quedan {max_intentos - intentos} intentos disponibles.")

        # Verificar si se han agotado los intentos
        if intentos == max_intentos:
            print("Se han agotado todos los intentos. Su cuenta ha sido bloqueada, por favor llame a Banco Popular lo antes posible.")

print("Gracias por utilizar nuestros servicios.")
