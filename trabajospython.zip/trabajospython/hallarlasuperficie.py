Lado=input("ingrese la medida de lado del cuadrado")
Lado=float(Lado)
superficie=Lado*Lado
print("La superficie es : ")
print(superficie)
