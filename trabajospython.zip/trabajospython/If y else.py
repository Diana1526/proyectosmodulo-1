
# Función para determinar la elegibilidad de la tarjeta de crédito
def determinar_eligibilidad(edad, sueldo, tiempo_trabajado, buen_credito):
    if edad < 18:
        return "No aplicas: Eres menor de edad."
    elif edad >= 18 and tiempo_trabajado < 6:
        return "No aplicas: No has trabajado por lo menos 6 meses."
    elif not buen_credito:
        return "No aplicas: No tienes buen crédito."
    else:
        if sueldo > 35000:
            return "Aplicas para una tarjeta con beneficios."
        elif 20000 < sueldo <= 35000:
            return "Aplicas para una tarjeta regular."

            return "No aplicas: Debes buscar un mejor empleo."

# Solicitar información al usuario
edad = int(input("Introduce tu edad: "))
sueldo = float(input("Introduce tu sueldo actual: "))
tiempo_trabajado = int(input("Introduce el tiempo que has trabajado en meses: "))
buen_credito = input("¿Tienes buen crédito? (sí/no): ").strip().lower() == 'sí'

# Determinar la elegibilidad y mostrar el resultado
resultado = determinar_eligibilidad(edad, sueldo, tiempo_trabajado, buen_credito)
print(resultado)

